# chrome-extension

## Description
Simple Chrome extension that allows you to import Bookmarks from a JSON file.

![alt text](img/image.png)
